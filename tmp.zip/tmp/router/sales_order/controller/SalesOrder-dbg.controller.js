sap.ui.define(["sap/ui/core/mvc/Controller", "../utils/Filters", "sap/ui/model/Sorter", "../utils/CartManager", "../utils/NavigationManager"], function (Controller, __Filters, Sorter, __CartManager, __NavigationManager) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const Filters = _interopRequireDefault(__Filters);
  const CategorySorter = _interopRequireDefault(__Filters);
  const CartManager = _interopRequireDefault(__CartManager);
  const NavigationManager = _interopRequireDefault(__NavigationManager);
  /**
   * @namespace sap.capire.gameshop.controller
   */
  const SalesOrder = Controller.extend("sap.capire.gameshop.controller.SalesOrder", {
    constructor: function constructor() {
      Controller.prototype.constructor.apply(this, arguments);
      this._bSortTitleDescending = false;
      this._bSortPriceDescending = false;
    },
    onInit: function _onInit() {
      const oSelect = this.byId("categorySelect");
      CategorySorter.initAndLoad(oSelect);
    },
    // Image placeholder for the game list
    onImageLoadError: function _onImageLoadError(oEvent) {
      NavigationManager.onImageLoadError(oEvent);
    },
    // Interactive sorting by Title
    onSortTitle: function _onSortTitle() {
      const oTable = this.byId("gamesTable");
      const oBinding = oTable?.getBinding("items");
      if (oBinding) {
        this._bSortTitleDescending = !this._bSortTitleDescending;
        const oSorter = new Sorter("title", this._bSortTitleDescending);
        oBinding.sort(oSorter);
      }
    },
    // Interactive sorting by Price
    onSortPrice: function _onSortPrice() {
      const oTable = this.byId("gamesTable");
      const oBinding = oTable?.getBinding("items");
      if (oBinding) {
        this._bSortPriceDescending = !this._bSortPriceDescending;
        const oSorter = new Sorter("price", this._bSortPriceDescending);
        oBinding.sort(oSorter);
      }
    },
    // Games filtration by Title
    onCatalogFiltersTrigger: function _onCatalogFiltersTrigger() {
      Filters.executeCatalogFiltration(this);
    },
    // Navigation method
    onNavToGenericDetails: function _onNavToGenericDetails(oEvent) {
      NavigationManager.navToGenericDetails(this, oEvent);
    },
    // Quick add to Cart
    onQuickAddToCart: function _onQuickAddToCart(oEvent) {
      const oButton = oEvent.getSource();
      const oContext = oButton.getBindingContext();
      if (!oContext) return;
      const sId = oContext.getProperty("ID");
      const sTitle = oContext.getProperty("title");
      const fPrice = oContext.getProperty("price");
      const oCartModel = this.getOwnerComponent()?.getModel("cart");
      CategorySorter.initAndLoad;
      CartManager.addToCart(oCartModel, sId, sTitle, fPrice, 1);
    }
  });
  return SalesOrder;
});
//# sourceMappingURL=SalesOrder-dbg.controller.js.map
