sap.ui.define(["sap/ui/core/mvc/Controller", "../utils/LoginManager", "../utils/NavigationManager"], function (Controller, __LoginManager, __NavigationManager) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const LoginManager = _interopRequireDefault(__LoginManager);
  const NavigationManager = _interopRequireDefault(__NavigationManager);
  /**
   * @namespace sap.capire.gameshop.controller
   */
  const App = Controller.extend("sap.capire.gameshop.controller.App", {
    onInit: function _onInit() {
      const oView = this.getView();
      if (!oView) return;
      const oODataModel = oView.getModel();
      const oRoleModel = oView.getModel("userRoles");
      if (oODataModel && oRoleModel) {
        LoginManager.checkSilentLogin(oView, oODataModel, oRoleModel);
      }
    },
    onNavToHome: function _onNavToHome() {
      NavigationManager.navTo(this, "SalesOrder");
    },
    onNavToOrders: function _onNavToOrders() {
      NavigationManager.navTo(this, "OrdersList");
    },
    onNavToCart: function _onNavToCart() {
      NavigationManager.navTo(this, "Cart");
    },
    onNavToProfile: function _onNavToProfile() {
      NavigationManager.navTo(this, "ClientProfile");
    },
    onLoginPress: function _onLoginPress() {
      const oView = this.getView();
      const oODataModel = oView?.getModel();
      const oRoleModel = oView?.getModel("userRoles");
      if (oView && oODataModel && oRoleModel) {
        LoginManager.runLoginDialog(oView, oODataModel, oRoleModel);
      }
    }
  });
  return App;
});
//# sourceMappingURL=App-dbg.controller.js.map
