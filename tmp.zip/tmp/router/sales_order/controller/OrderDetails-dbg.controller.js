sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/json/JSONModel", "sap/m/MessageBox", "../utils/NavigationManager", "../utils/OrderManager", "../model/formatter", "sap/ui/core/Fragment"], function (Controller, JSONModel, MessageBox, __NavigationManager, __OrderManager, __Formatter, Fragment) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const NavigationManager = _interopRequireDefault(__NavigationManager);
  const OrderManager = _interopRequireDefault(__OrderManager);
  const Formatter = _interopRequireDefault(__Formatter);
  /**
   * @namespace sap.capire.gameshop.controller
   */
  const OrderDetails = Controller.extend("sap.capire.gameshop.controller.OrderDetails", {
    constructor: function constructor() {
      Controller.prototype.constructor.apply(this, arguments);
      this.formatter = Formatter;
      this._oCancelDialog = null;
    },
    onInit: function _onInit() {
      const oOwnerComponent = this.getOwnerComponent();
      oOwnerComponent?.getRouter().getRoute("OrderDetails")?.attachPatternMatched(this._onOrderMatched, this);
      const oLocalModel = new JSONModel({
        isReviewLocked: false,
        isReviewFormVisible: false,
        isReviewReadOnlyVisible: false
      });
      this.getView()?.setModel(oLocalModel, "localView");
      const oValueHelpsModel = new JSONModel();
      oValueHelpsModel.loadData("model/valueHelps.json");
      this.getView()?.setModel(oValueHelpsModel, "valueHelps");
    },
    onImageLoadError: function _onImageLoadError(oEvent) {
      NavigationManager.onImageLoadError(oEvent);
    },
    onNavBack: function _onNavBack() {
      NavigationManager.navBack(this, "OrdersList");
    },
    _onOrderMatched: function _onOrderMatched(oEvent) {
      const oArgs = oEvent.getParameter("arguments");
      const sOrderId = oArgs?.orderId;
      const oView = this.getView();
      if (!oView || !sOrderId) return;
      oView.bindElement({
        path: `/Orders(ID=${sOrderId},IsActiveEntity=true)`,
        parameters: {
          $expand: "customer,items($expand=game)"
        },
        events: {
          dataRequested: () => oView.setBusy(true),
          dataReceived: async () => {
            oView.setBusy(false);
            const oBindingContext = oView.getBindingContext();
            const oOrderData = oBindingContext?.getObject();
            const oDiscountAttr = this.byId("discountAttribute");
            const oCancelBtn = this.byId("cancelOrderButton");
            const oUserRoles = oView.getModel("userRoles");
            OrderManager.calculateLoyaltySaving(oOrderData, oDiscountAttr);
            OrderManager.updateCancelButtonVisibility(oCancelBtn, oOrderData, oUserRoles);
            OrderManager.enforceSecurityShield(this, oOrderData, oUserRoles);
            await OrderManager.checkAndPrepareReviewContainer(this, oOrderData);
          }
        }
      });
    },
    onSubmitReview: async function _onSubmitReview() {
      const oBindingContext = this.getView()?.getBindingContext();
      const oOrderData = oBindingContext?.getObject();
      await OrderManager.submitOrderReview(this, oOrderData);
    },
    onCancelOrder: async function _onCancelOrder() {
      const oView = this.getView();
      if (!oView) return;
      if (!this._oCancelDialog) {
        this._oCancelDialog = await Fragment.load({
          id: oView.getId(),
          name: "sap.capire.gameshop.view.fragments.ActionDialog",
          controller: this
        });
        oView.addDependent(this._oCancelDialog);
      }
      oView.byId("reasonInput").setValue("");
      oView.byId("destinationInput").setValue("");
      oView.byId("cancelCommentArea").setValue("");
      this._oCancelDialog.open();
    },
    onReasonValueHelp: function _onReasonValueHelp() {
      const oInput = this.getView()?.byId("reasonInput");
      OrderManager.openValueHelp(this, oInput, "orderDetails.dialog.cancelReason.title", "valueHelps>/cancellationReasons");
    },
    onDestinationValueHelp: function _onDestinationValueHelp() {
      const oInput = this.getView()?.byId("destinationInput");
      OrderManager.openValueHelp(this, oInput, "orderDetails.dialog.licensePlatform.title", "valueHelps>/licensePlatforms");
    },
    onConfirmOrderCancellation: async function _onConfirmOrderCancellation() {
      await OrderManager.executeOrderCancellation(this, this._oCancelDialog);
    },
    onCloseCancelDialog: function _onCloseCancelDialog() {
      this._oCancelDialog?.close();
    },
    onDeleteOrder: function _onDeleteOrder() {
      const oView = this.getView();
      const oBindingContext = oView?.getBindingContext();
      if (!oBindingContext) return;
      const oResourceBundle = this.getOwnerComponent()?.getModel("i18n")?.getResourceBundle();
      MessageBox.warning(oResourceBundle?.getText("orderDetails.message.deleteConfirm") || "", {
        actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
        emphasizedAction: MessageBox.Action.CANCEL,
        onClose: async sAction => {
          if (sAction !== MessageBox.Action.OK) return;
          try {
            oView.setBusy(true);
            await oBindingContext.delete();
            oView.setBusy(false);
            MessageBox.success(oResourceBundle?.getText("orderDetails.message.deleteSuccess") || "", {
              onClose: () => this.onNavBack()
            });
          } catch (oError) {
            oView.setBusy(false);
            MessageBox.error(oError?.message || oResourceBundle?.getText("orderDetails.message.deleteError") || "");
          }
        }
      });
    }
  });
  return OrderDetails;
});
//# sourceMappingURL=OrderDetails-dbg.controller.js.map
