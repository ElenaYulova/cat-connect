sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/core/UIComponent", "sap/ui/model/json/JSONModel", "sap/m/MessageToast", "../utils/CartManager", "../model/formatter"], function (Controller, UIComponent, JSONModel, MessageToast, __CartManager, __Formatter) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const CartManager = _interopRequireDefault(__CartManager);
  const Formatter = _interopRequireDefault(__Formatter);
  const ProductDetails = Controller.extend("webapp.controller.ProductDetails", {
    constructor: function constructor() {
      Controller.prototype.constructor.apply(this, arguments);
      this.formatter = Formatter;
    },
    onInit: function _onInit() {
      const oRouter = UIComponent.getRouterFor(this);
      oRouter.getRoute("ProductDetails")?.attachPatternMatched(this._onObjectMatched, this);
    },
    _onObjectMatched: function _onObjectMatched(oEvent) {
      const oParameters = oEvent.getParameters();
      const oArgs = oParameters?.arguments;
      if (!oArgs || !oArgs.productId) return;
      const sProductId = oArgs.productId;
      const oView = this.getView();
      if (!oView) return;
      const oComponent = this.getOwnerComponent();
      const oCartModel = oComponent ? oComponent.getModel("cart") : null;
      if (!oCartModel) return;
      const iValidQuantity = CartManager.getQuantityForProduct(oCartModel, sProductId);
      let oViewModel = oView.getModel("view");
      if (!oViewModel) {
        oViewModel = new JSONModel();
        oView.setModel(oViewModel, "view");
      }
      oViewModel.setProperty("/currentQuantity", iValidQuantity);
      oViewModel.setProperty("/isEditMode", false);
      oViewModel.setProperty("/isAddToCartEnabled", true);
      oView.bindElement({
        path: `/Products(${sProductId})`,
        parameters: {
          $$updateGroupId: "detailsUpdateGroup",
          "$expand": "genre($select=ID,name)"
        }
      });
    },
    onQuantityChange: function _onQuantityChange(oEvent) {
      const oControl = oEvent.getSource();
      if (!oControl) return;
      const oStepInput = oControl;
      const oView = this.getView();
      if (!oView) return;
      const oViewModel = oView.getModel("view");
      if (oViewModel) {
        const bIsValid = oStepInput.getValueState() !== "Error";
        oViewModel.setProperty("/isAddToCartEnabled", bIsValid);
      }
    },
    onAddToCart: function _onAddToCart() {
      const oView = this.getView();
      const oContext = oView?.getBindingContext();
      if (!oContext) return;
      const sId = oContext.getProperty("ID");
      const sTitle = oContext.getProperty("title");
      const fPrice = oContext.getProperty("price");
      const oCartModel = this.getOwnerComponent()?.getModel("cart");
      const oViewModel = oView?.getModel("view");
      if (!oCartModel || !oViewModel) return;
      const iQuantity = oViewModel.getProperty("/currentQuantity") || 1;
      CartManager.addToCart(oCartModel, sId, sTitle, fPrice, iQuantity);
    },
    onEditProduct: function _onEditProduct() {
      const oView = this.getView();
      const oRolesModel = oView?.getModel("userRoles");
      const oViewModel = oView?.getModel("view");
      if (!oRolesModel || !oViewModel) return;
      const bIsLoggedIn = oRolesModel.getProperty("/isLoggedIn");
      const bIsCRMAdmin = oRolesModel.getProperty("/isCRMAdmin");
      const bIsSupplier = oRolesModel.getProperty("/isSupplier");
      const oResourceBundle = this.getOwnerComponent()?.getModel("i18n")?.getResourceBundle();
      if (!bIsLoggedIn || !bIsCRMAdmin && !bIsSupplier) {
        MessageToast.show(oResourceBundle?.getText("productDetails.message.accessDenied") || "");
        return;
      }
      oViewModel.setProperty("/isEditMode", true);
      MessageToast.show(oResourceBundle?.getText("productDetails.message.editEnabled") || "");
    },
    onSaveChanges: async function _onSaveChanges() {
      const oResourceBundle = this.getOwnerComponent()?.getModel("i18n")?.getResourceBundle();
      const oView = this.getView();
      if (!oView) return;
      const oModel = oView.getModel();
      const oViewModel = oView.getModel("view");
      try {
        await oModel.submitBatch("detailsUpdateGroup");
        oViewModel.setProperty("/isEditMode", false);
        MessageToast.show(oResourceBundle?.getText("productDetails.message.saveSuccess") || "");
      } catch (oError) {
        MessageToast.show(oResourceBundle?.getText("productDetails.message.saveError") || "");
      }
    },
    onCancelChanges: function _onCancelChanges() {
      const oView = this.getView();
      const oViewModel = oView?.getModel("view");
      if (!oView || !oViewModel) return;
      const oModel = oView.getModel();
      const oResourceBundle = this.getOwnerComponent()?.getModel("i18n")?.getResourceBundle();
      oModel.resetChanges("detailsUpdateGroup");
      oViewModel.setProperty("/isEditMode", false);
      MessageToast.show(oResourceBundle?.getText("productDetails.message.changesDiscarded") || "");
    },
    onPriceLiveChange: function _onPriceLiveChange(oEvent) {
      Formatter.onPriceLiveChange(oEvent);
    },
    onStockLiveChange: function _onStockLiveChange(oEvent) {
      Formatter.onStockLiveChange(oEvent);
    },
    onImageLoadError: function _onImageLoadError(oEvent) {
      const oImageCtrl = oEvent.getSource();
      if (oImageCtrl) {
        oImageCtrl.setSrc("./assets/img/logo.png");
      }
    }
  });
  return ProductDetails;
});
//# sourceMappingURL=ProductDetails-dbg.controller.js.map
