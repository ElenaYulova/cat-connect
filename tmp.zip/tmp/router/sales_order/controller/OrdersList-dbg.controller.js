sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/Sorter", "../utils/Filters", "../utils/NavigationManager", "../model/formatter"], function (Controller, Sorter, __Filters, __NavigationManager, __Formatter) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const Filters = _interopRequireDefault(__Filters);
  const NavigationManager = _interopRequireDefault(__NavigationManager);
  const Formatter = _interopRequireDefault(__Formatter);
  /**
   * @namespace sap.capire.gameshop.controller
   */
  const OrdersList = Controller.extend("sap.capire.gameshop.controller.OrdersList", {
    constructor: function constructor() {
      Controller.prototype.constructor.apply(this, arguments);
      this.formatter = Formatter;
      this._bSortOrderDescending = false;
      this._bSortAmountDescending = false;
      this._bSortDateDescending = false;
      this._bSortStatusDescending = false;
    },
    /**
     * Forcibly triggers OData v4 model context synchronization reload
     */
    onRefreshOrders: function _onRefreshOrders() {
      const oTable = this.byId("ordersTable");
      const oBinding = oTable?.getBinding("items");
      if (oBinding) {
        oBinding.refresh();
      }
    },
    onApplyFilters: function _onApplyFilters() {
      Filters.executeOrdersListFiltration(this);
    },
    /**
     * Resets all filter components back to default factory states
     */
    onResetFilters: function _onResetFilters() {
      const oSearchField = this.byId("filterOrderNumber");
      const oSelect = this.byId("filterStatus");
      const oDateRange = this.byId("filterDateRange");
      if (oSearchField) oSearchField.setValue("");
      if (oSelect) oSelect.setSelectedKey("ALL");
      if (oDateRange) oDateRange.setValue("");
      this.onApplyFilters();
    },
    /**
     * Sorters
     */
    onSortOrderNumber: function _onSortOrderNumber() {
      const oTable = this.byId("ordersTable");
      const oBinding = oTable?.getBinding("items");
      if (oBinding) {
        this._bSortOrderDescending = !this._bSortOrderDescending;
        const oSorter = new Sorter("orderNumber", this._bSortOrderDescending);
        oBinding.sort(oSorter);
      }
    },
    onSortTotalAmount: function _onSortTotalAmount() {
      const oTable = this.byId("ordersTable");
      const oBinding = oTable?.getBinding("items");
      if (oBinding) {
        this._bSortAmountDescending = !this._bSortAmountDescending;
        const oSorter = new Sorter("totalAmount", this._bSortAmountDescending);
        oBinding.sort(oSorter);
      }
    },
    onSortCreatedAt: function _onSortCreatedAt() {
      const oTable = this.byId("ordersTable");
      const oBinding = oTable?.getBinding("items");
      if (oBinding) {
        this._bSortDateDescending = !this._bSortDateDescending;
        const oSorter = new Sorter("createdAt", this._bSortDateDescending);
        oBinding.sort(oSorter);
      }
    },
    onSortStatus: function _onSortStatus() {
      const oTable = this.byId("ordersTable");
      const oBinding = oTable?.getBinding("items");
      if (oBinding) {
        this._bSortStatusDescending = !this._bSortStatusDescending;
        const oSorter = new Sorter("status_code", this._bSortStatusDescending);
        oBinding.sort(oSorter);
      }
    },
    onNavBack: function _onNavBack() {
      NavigationManager.navBack(this, "SalesOrder");
    },
    onOrderDetailsPress: function _onOrderDetailsPress(oEvent) {
      const oItem = oEvent.getSource();
      const oBindingContext = oItem.getBindingContext();
      if (!oBindingContext) return;
      const sOrderId = oBindingContext.getProperty("ID");
      NavigationManager.navTo(this, "OrderDetails", {
        orderId: sOrderId
      });
    }
  });
  return OrdersList;
});
//# sourceMappingURL=OrdersList-dbg.controller.js.map
