sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/json/JSONModel", "../utils/NavigationManager", "../utils/CustomerManager", "sap/m/MessageBox"], function (Controller, JSONModel, __NavigationManager, __CustomerManager, MessageBox) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const NavigationManager = _interopRequireDefault(__NavigationManager);
  const CustomerManager = _interopRequireDefault(__CustomerManager);
  /**
   * @namespace sap.capire.gameshop.controller
   */
  const ClientProfile = Controller.extend("sap.capire.gameshop.controller.ClientProfile", {
    onInit: function _onInit() {
      const oOwnerComponent = this.getOwnerComponent();
      oOwnerComponent?.getRouter().getRoute("ClientProfile")?.attachPatternMatched(this._onProfileMatched, this);
      const oLocalModel = new JSONModel({
        isEditMode: false
      });
      this.getView()?.setModel(oLocalModel, "localView");
    },
    onNavBack: function _onNavBack() {
      NavigationManager.navBack(this, "SalesOrder");
    },
    _onProfileMatched: async function _onProfileMatched(oEvent) {
      const oView = this.getView();
      if (!oView) return;
      try {
        oView.setBusy(true);
        await CustomerManager.bindProfileView(oView, () => this.onNavBack());
      } catch (oError) {
        const oResourceBundle = this.getOwnerComponent()?.getModel("i18n")?.getResourceBundle();
        MessageBox.error(oResourceBundle?.getText("clientProfile.message.initFailed", [oError.message]) || `Profile initialization failed: ${oError.message}`);
      } finally {
        oView.setBusy(false);
      }
    },
    onEditPress: function _onEditPress() {
      const oLocalModel = this.getView()?.getModel("localView");
      oLocalModel?.setProperty("/isEditMode", true);
    },
    onCancelPress: function _onCancelPress() {
      const oView = this.getView();
      const oLocalModel = oView?.getModel("localView");
      oLocalModel?.setProperty("/isEditMode", false);
      const oBindingContext = oView?.getBindingContext();
      if (oBindingContext?.getBinding().hasPendingChanges()) {
        oBindingContext.getBinding().resetChanges();
      }
    }
  });
  return ClientProfile;
});
//# sourceMappingURL=ClientProfile-dbg.controller.js.map
