sap.ui.define(["sap/ui/core/mvc/Controller", "../utils/CartManager", "../utils/NavigationManager"], function (Controller, __CartManager, __NavigationManager) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const CartManager = _interopRequireDefault(__CartManager);
  const NavigationManager = _interopRequireDefault(__NavigationManager);
  const Cart = Controller.extend("webapp.controller.Cart", {
    onInit: function _onInit() {
      const oOwnerComponent = this.getOwnerComponent();
      oOwnerComponent?.getRouter().getRoute("Cart")?.attachPatternMatched(this._onCartMatched, this);
    },
    _onCartMatched: async function _onCartMatched() {
      const oView = this.getView();
      const oODataModel = oView?.getModel();
      const oCartModel = oView?.getModel("cart");
      if (oView && oODataModel && oCartModel) {
        await CartManager.validateBulkEligibility(oView, oODataModel);
        CartManager.triggerRefresh(oCartModel);
      }
    },
    onNavBack: function _onNavBack() {
      NavigationManager.navBack(this, "SalesOrder");
    },
    onQuantityChange: function _onQuantityChange(oEvent) {
      const oStepInput = oEvent.getSource();
      const iNewValue = oStepInput.getValue();
      const oContext = oStepInput.getParent().getBindingContext("cart");
      if (!oContext) return;
      CartManager.updateQuantity(this.getView()?.getModel("cart"), oContext.getProperty("id"), iNewValue);
    },
    onRemoveItem: function _onRemoveItem(oEvent) {
      const oContext = oEvent.getSource().getParent().getBindingContext("cart");
      if (oContext) {
        CartManager.removeFromCart(this.getView()?.getModel("cart"), oContext.getProperty("id"));
      }
    },
    onSubmitOrder: function _onSubmitOrder() {
      const oView = this.getView();
      const oCartModel = oView?.getModel("cart");
      const oODataModel = oView?.getModel();
      if (oView && oCartModel && oODataModel) {
        CartManager.submitOrder(oView, oODataModel, oCartModel);
      }
    },
    onImageLoadError: function _onImageLoadError(oEvent) {
      NavigationManager.onImageLoadError(oEvent);
    }
  });
  return Cart;
});
//# sourceMappingURL=Cart-dbg.controller.js.map
