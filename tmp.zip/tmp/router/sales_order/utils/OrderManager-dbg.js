sap.ui.define(["sap/m/MessageBox", "sap/m/SelectDialog", "sap/m/StandardListItem"], function (MessageBox, SelectDialog, StandardListItem) {
  "use strict";

  class OrderManager {
    /**
     * TODO: Add feature with Loyalty Saving Sums in next releases.
     */
    static calculateLoyaltySaving(oOrder, oDiscountAttr) {
      if (!oDiscountAttr) return;
      if (!oOrder || !oOrder.items) {
        oDiscountAttr.setText("");
        return;
      }
      let fTotalGross = 0;
      oOrder.items.forEach(oItem => {
        const fPrice = oItem.game?.price || 0;
        const iQty = oItem.quantity || 0;
        fTotalGross += fPrice * iQty;
      });
      const fTotalAmount = oOrder.totalAmount || 0;
      const fSaving = +(fTotalGross - fTotalAmount).toFixed(2);
      const oBundle = sap.ui.getCore().getModel("i18n")?.getResourceBundle();
      if (fSaving > 0) {
        oDiscountAttr.setText(oBundle?.getText("orderManager.label.loyaltySaving", [fSaving]) || `Your Loyalty Saving: ${fSaving} USD`);
      } else {
        oDiscountAttr.setText("");
      }
    }
    static updateCancelButtonVisibility(oCancelBtn, oOrderData, oUserRoles) {
      if (!oCancelBtn || !oOrderData) return;
      const sStatus = oOrderData.status_code;
      const bIsSupplier = oUserRoles?.getProperty("/isSupplier") === true;
      const bVisible = !bIsSupplier && (sStatus === "new" || sStatus === "N" || sStatus === "in_process" || sStatus === "P");
      oCancelBtn.setVisible(bVisible);
    }
    static enforceSecurityShield(oController, oOrderData, oUserRoles) {
      if (!oOrderData) return;
      const oBundle = sap.ui.getCore().getModel("i18n")?.getResourceBundle();
      const sSavedUserJson = window.localStorage.getItem("catConnect_userProfile");
      if (sSavedUserJson) {
        try {
          const oUserData = JSON.parse(sSavedUserJson);
          if (oUserData.isCRMAdmin === true || oUserData.isSalesManager === true) {
            return;
          }
          const sOrderCustomerId = oOrderData.customer_ID || oOrderData.customer?.ID;
          if (sOrderCustomerId !== oUserData.id) {
            MessageBox.error(oBundle?.getText("orderManager.message.accessDenied") || "Access Denied: You cannot view other customers' orders.", {
              onClose: () => {
                if (typeof oController.onNavBack === "function") {
                  oController.onNavBack();
                }
              }
            });
          }
        } catch (e) {
          console.error("[AUTODEV SEC-SHIELD CRASH]: Failed to parse local session token.");
        }
      }
    }
    static async checkAndPrepareReviewContainer(oController, oOrderData) {
      const oView = oController.getView();
      const oLocalModel = oView?.getModel("localView");
      if (!oView || !oLocalModel || !oOrderData) return;
      const oBundle = sap.ui.getCore().getModel("i18n")?.getResourceBundle();
      const sStatus = oOrderData.status_code;
      const sOrderId = oOrderData.ID;
      const sCustomerId = oOrderData.customer?.ID || oOrderData.customer_ID;
      const bIsCompleted = sStatus === "completed" || sStatus === "C";
      const bIsCanceled = sStatus === "canceled" || sStatus === "X";

      // TODO: Refactor UI layout for canceled state to completely hide unused labels (Your Rating/Comment)
      // and shift to a dedicated encapsulated fragments block before final mentor review.
      if (bIsCanceled) {
        oLocalModel.setProperty("/isReviewLocked", false);
        oLocalModel.setProperty("/isReviewFormVisible", false);
        oLocalModel.setProperty("/isReviewReadOnlyVisible", true);
      } else if (!bIsCompleted) {
        oLocalModel.setProperty("/isReviewLocked", true);
        oLocalModel.setProperty("/isReviewFormVisible", false);
        oLocalModel.setProperty("/isReviewReadOnlyVisible", false);
        return;
      } else {
        oLocalModel.setProperty("/isReviewLocked", false);
      }
      const oODataModel = oView.getModel();
      oView.setBusy(true);
      try {
        let sFilterQuery = `customer_ID eq ${sCustomerId} and product_ID eq 44444444-4444-4444-4444-444444444444 and contains(comments,'${sOrderId}')`;
        if (bIsCanceled) {
          sFilterQuery = `customer_ID eq ${sCustomerId} and contains(comments,'[CANCELED]') and contains(comments,'${sOrderId}')`;
        }
        const oListBinding = oODataModel.bindList("/Feedbacks", undefined, undefined, undefined, {
          $filter: sFilterQuery
        });
        const aContexts = await oListBinding.requestContexts(0, 1);
        oView.setBusy(false);
        if (aContexts && aContexts.length > 0) {
          const oSavedReview = aContexts[0].getObject();
          if (oSavedReview.rating === 0 || oSavedReview.comments.includes("[CANCELED]")) {
            oLocalModel.setProperty("/isReviewFormVisible", false);
            oLocalModel.setProperty("/isReviewReadOnlyVisible", true);
            const sCleanComment = oSavedReview.comments.replace("[CANCELED]", oBundle?.getText("orderManager.status.canceled") || "🛑 STATUS: CANCELED |").replace(/\[/g, " ").replace(/\]/g, " |");
            oView.byId("savedRatingIndicator")?.setValue(0);
            oView.byId("savedRatingIndicator")?.setVisible(false);
            oView.byId("savedCommentText")?.setText(sCleanComment);
          } else {
            oLocalModel.setProperty("/isReviewFormVisible", false);
            oLocalModel.setProperty("/isReviewReadOnlyVisible", true);
            oView.byId("savedRatingIndicator")?.setVisible(true);
            const sCleanComment = oSavedReview.comments.replace(`[Order_ID: ${sOrderId}]`, "").trim();
            oView.byId("savedRatingIndicator")?.setValue(oSavedReview.rating);
            oView.byId("savedCommentText")?.setText(sCleanComment);
          }
        } else {
          if (bIsCanceled) {
            oLocalModel.setProperty("/isReviewFormVisible", false);
            oLocalModel.setProperty("/isReviewReadOnlyVisible", true);
            oView.byId("savedRatingIndicator")?.setVisible(false);
            oView.byId("savedCommentText")?.setText(oBundle?.getText("orderManager.log.revoked") || "🛑 System Log: This digital key contract has been revoked and canceled.");
          } else {
            oLocalModel.setProperty("/isReviewFormVisible", true);
            oLocalModel.setProperty("/isReviewReadOnlyVisible", false);
            oView.byId("savedRatingIndicator")?.setVisible(true);
          }
        }
      } catch (oError) {
        oView.setBusy(false);
        oLocalModel.setProperty("/isReviewFormVisible", true);
      }
    }
    static async submitOrderReview(oController, oOrderData) {
      const oView = oController.getView();
      if (!oView || !oOrderData) return;
      const oRatingCtrl = oView.byId("feedbackRatingIndicator");
      const oTextCtrl = oView.byId("feedbackTextArea");
      const oODataModel = oView.getModel();
      const oBundle = sap.ui.getCore().getModel("i18n")?.getResourceBundle();
      const iRating = Math.max(1, oRatingCtrl?.getValue() || 5);
      const sComment = oTextCtrl?.getValue()?.trim() || "";
      if (!sComment) {
        MessageBox.warning(oBundle?.getText("orderManager.message.reviewWarning") || "Please enter your review text before submitting.");
        return;
      }
      oView.setBusy(true);
      try {
        const sFakeStoreProductId = "44444444-4444-4444-4444-444444444444";
        const sMaskedComment = `[Order_ID: ${oOrderData.ID}] ${sComment}`;
        const sCleanDate = new Date().toISOString().split("T")[0];
        const oListBinding = oODataModel.bindList("/Feedbacks");
        await oListBinding.create({
          customer_ID: oOrderData.customer_ID,
          product_ID: sFakeStoreProductId,
          rating: iRating,
          comments: sMaskedComment,
          feedbackDate: sCleanDate
        }, true);
        OrderManager._toggleReviewUIState(oView, iRating, sComment);
        MessageBox.success(oBundle?.getText("orderManager.message.reviewSuccess") || "Thank you! Your store review has been successfully submitted and factored into your loyalty profile.");
      } catch (oError) {
        MessageBox.error(oError?.message || oBundle?.getText("orderManager.message.reviewError") || "Failed to save your review.");
      } finally {
        oView.setBusy(false);
      }
    }
    static _toggleReviewUIState(oView, iRating, sComment) {
      const oLocalModel = oView.getModel("localView");
      if (!oLocalModel) return;
      oLocalModel.setProperty("/isReviewFormVisible", false);
      oLocalModel.setProperty("/isReviewReadOnlyVisible", true);
      oView.byId("savedRatingIndicator")?.setValue(iRating);
      oView.byId("savedCommentText")?.setText(sComment);
    }
    static async executeOrderCancellation(oController, oCancelDialog) {
      const oView = oController.getView();
      const oODataModel = oView?.getModel();
      const oBindingContext = oView?.getBindingContext();
      if (!oView || !oODataModel || !oBindingContext || !oCancelDialog) return;
      const oBundle = sap.ui.getCore().getModel("i18n")?.getResourceBundle();
      const sReason = oView.byId("reasonInput").getValue().trim();
      const sPlatform = oView.byId("destinationInput").getValue().trim();
      const sComment = oView.byId("cancelCommentArea").getValue().trim();
      if (!sReason || !sPlatform) {
        MessageBox.error(oBundle?.getText("orderManager.message.cancelValidation") || "Please select both Cancellation Reason and License Platform using Search Helps.");
        return;
      }
      oView.setBusy(true);
      oCancelDialog.setBusy(true);
      try {
        const oActionContext = oODataModel.bindContext(`${oBindingContext.getPath()}/SalesOrderService.cancelOrder(...)`);
        oActionContext.setParameter("reasonCode", sReason);
        oActionContext.setParameter("platformCode", sPlatform);
        oActionContext.setParameter("comment", sComment);
        await oActionContext.execute();
        oCancelDialog.setBusy(false);
        oCancelDialog.close();
        oView.setBusy(false);
        const oViewBinding = oView.getBindingContext()?.getBinding();
        if (oViewBinding && typeof oViewBinding.refresh === "function") {
          oViewBinding.refresh();
        }
        MessageBox.success(oBundle?.getText("orderManager.message.cancelSuccess") || "Order has been successfully canceled!");
      } catch (oError) {
        oCancelDialog.setBusy(false);
        oView.setBusy(false);
        MessageBox.error(oError?.message || oBundle?.getText("orderManager.message.cancelError") || "Fatal error during order cancellation transaction.");
      }
    }
    static openValueHelp(oController, oInput, sTitleKey, sAggregationPath) {
      const oView = oController.getView();
      const oModel = oView?.getModel("valueHelps");
      const oI18nModel = oView?.getModel("i18n");
      if (!oView || !oInput || !oModel) return;
      const oResourceBundle = oI18nModel?.getResourceBundle();
      const sTitle = oResourceBundle?.getText(sTitleKey) || "Select Option";
      const oSelectDialog = new SelectDialog({
        title: sTitle,
        confirm: oEvent => {
          const oSelectedItem = oEvent.getParameter("selectedItem");
          if (oSelectedItem) {
            oInput.setValue(oSelectedItem.getTitle());
          }
        }
      });
      oSelectDialog.setModel(oModel, "valueHelps");
      oSelectDialog.bindAggregation("items", {
        path: sAggregationPath,
        factory: (sId, oContext) => {
          const sRawCode = oContext.getProperty("code") || "";
          const sRawText = oContext.getProperty("text") || "";
          const sCleanCodeKey = sRawCode.replace("{i18n>", "").replace("}", "");
          const sCleanTextKey = sRawText.replace("{i18n>", "").replace("}", "");
          const sTranslatedTitle = oResourceBundle?.getText(sCleanCodeKey) || sRawCode;
          const sTranslatedDesc = oResourceBundle?.getText(sCleanTextKey) || sRawText;
          return new StandardListItem(sId, {
            title: sTranslatedTitle,
            description: sTranslatedDesc
          });
        }
      });
      oSelectDialog.open("");
    }
  }
  return OrderManager;
});
//# sourceMappingURL=OrderManager-dbg.js.map
