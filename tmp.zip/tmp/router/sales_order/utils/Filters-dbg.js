sap.ui.define(["sap/ui/core/Item", "sap/ui/model/Filter", "sap/ui/model/FilterOperator"], function (Item, Filter, FilterOperator) {
  "use strict";

  /**
   * @namespace sap.capire.gameshop.utils
   */
  class Filters {
    /**
     * Homepage Category Sorter
     */
    static initAndLoad(oComboBox) {
      if (!oComboBox) return;
      oComboBox.bindItems({
        path: "/Categories",
        parameters: {
          "$select": "ID,name,parent_ID",
          "$expand": "parent($select=name)"
        },
        template: new Item({
          key: "{ID}",
          text: "{name}"
        }),
        events: {
          dataReceived: () => {
            const oBinding = oComboBox.getBinding("items");
            if (!oBinding) return;
            const aRaw = oBinding.getContexts().map(oCtx => oCtx.getObject()).filter(oObj => !!oObj);
            Filters.rebuildItems(oComboBox, aRaw);
          }
        }
      });
    }
    static rebuildItems(oComboBox, aRawCategories) {
      const aParents = aRawCategories.filter(c => !c.parent_ID).sort((a, b) => a.name.localeCompare(b.name));
      const aResult = [...aParents];
      const aChildren = aRawCategories.filter(c => !!c.parent_ID).sort((a, b) => a.name.localeCompare(b.name));
      aChildren.forEach(oChild => {
        const iParentIndex = aResult.findIndex(c => c.ID === oChild.parent_ID);
        if (iParentIndex !== -1) {
          let iInsertIndex = iParentIndex + 1;
          while (iInsertIndex < aResult.length && aResult[iInsertIndex].parent_ID === oChild.parent_ID) {
            iInsertIndex++;
          }
          aResult.splice(iInsertIndex, 0, oChild);
        } else {
          aResult.push(oChild);
        }
      });
      oComboBox.destroyItems();
      aResult.forEach(oCat => {
        const sFormattedText = oCat.parent_ID ? `    └── ${oCat.name}` : oCat.name;
        oComboBox.addItem(new Item({
          key: oCat.ID,
          text: sFormattedText
        }));
      });
    }

    /**
     * Centralized Homepage Filter State
     */
    static executeCatalogFiltration(oController) {
      const oView = oController.getView();
      const oTable = oView?.byId("gamesTable");
      const oBinding = oTable?.getBinding("items");
      if (!oBinding) return;
      const oSearchField = oView.byId("searchTitleField");
      const oSelect = oView.byId("categorySelect");
      const oCheckBox = oView.byId("parentCategoryCheckBox");
      const oStockSwitch = oView.byId("stockFilterSwitch");
      const oPriceCombo = oView.byId("priceFilterCombo");
      const aFilters = [];

      // Filter by Name
      const sQuery = oSearchField ? oSearchField.getValue().trim() : "";
      if (sQuery) {
        aFilters.push(new Filter({
          path: "title",
          operator: FilterOperator.Contains,
          value1: sQuery,
          caseSensitive: false
        }));
      }

      // Filter by Stock
      const bInStockOnly = oStockSwitch ? oStockSwitch.getState() : false;
      if (bInStockOnly) {
        aFilters.push(new Filter("stock", FilterOperator.GT, 0));
      }

      // Filter by Price Limit
      const sPriceKey = oPriceCombo ? oPriceCombo.getSelectedKey() : "all";
      if (sPriceKey && sPriceKey !== "all") {
        aFilters.push(new Filter("price", FilterOperator.LE, Number(sPriceKey)));
      }

      // Filter by Category
      const sSelectedCategoryId = oSelect ? oSelect.getSelectedKey() : "";
      if (sSelectedCategoryId) {
        const oCurrentCategoryFilter = new Filter("genre_ID", FilterOperator.EQ, sSelectedCategoryId);
        if (oCheckBox && oCheckBox.getSelected()) {
          const oSelectedItem = oSelect.getSelectedItem();
          const oContext = oSelectedItem ? oSelectedItem.getBindingContext() : null;
          const sParentId = oContext ? oContext.getProperty("parent_ID") : null;
          if (sParentId) {
            aFilters.push(new Filter({
              filters: [oCurrentCategoryFilter, new Filter("genre_ID", FilterOperator.EQ, sParentId)],
              and: false
            }));
          } else {
            aFilters.push(new Filter({
              filters: [oCurrentCategoryFilter, new Filter("genre/parent_ID", FilterOperator.EQ, sSelectedCategoryId)],
              and: false
            }));
          }
        } else {
          aFilters.push(oCurrentCategoryFilter);
        }
      }
      oBinding.filter(aFilters.length > 0 ? new Filter({
        filters: aFilters,
        and: true
      }) : []);
    }

    /**
     * Centralized Order page Filter State
     */
    static executeOrdersListFiltration(oController) {
      const oView = oController.getView();
      const oTable = oView?.byId("ordersTable");
      const oBinding = oTable?.getBinding("items");
      if (!oBinding || !oView) return;
      const aFilters = [];
      const oSearchField = oView.byId("filterOrderNumber");
      const sSearchValue = oSearchField?.getValue()?.trim();
      if (sSearchValue) {
        aFilters.push(new Filter({
          filters: [new Filter("orderNumber", FilterOperator.Contains, sSearchValue), new Filter({
            path: "customer/name",
            operator: FilterOperator.Contains,
            value1: sSearchValue,
            caseSensitive: false
          })],
          and: false
        }));
      }

      // Filter by Status
      const oSelect = oView.byId("filterStatus");
      const sStatusKey = oSelect?.getSelectedKey();
      if (sStatusKey && sStatusKey !== "ALL") {
        aFilters.push(new Filter("status_code", FilterOperator.EQ, sStatusKey));
      }

      // Filter by DAta Range
      const oDateRange = oView.byId("filterDateRange");
      const oFromDate = oDateRange?.getDateValue();
      const oToDate = oDateRange?.getSecondDateValue();
      if (oFromDate && oToDate) {
        const oToDateEnd = new Date(oToDate);
        oToDateEnd.setHours(23, 59, 59, 999);
        aFilters.push(new Filter("createdAt", FilterOperator.BT, oFromDate.toISOString(), oToDateEnd.toISOString()));
      }
      oBinding.filter(aFilters);
    }
  }
  return Filters;
});
//# sourceMappingURL=Filters-dbg.js.map
