sap.ui.define(["sap/ui/core/routing/History"], function (History) {
  "use strict";

  class NavigationManager {
    /**
     * Standard back navigation handler returning user back to the previous view state safely
     */
    static navBack(oController, sDefaultRoute = "SalesOrder") {
      const oHistory = History.getInstance();
      const sPreviousHash = oHistory.getPreviousHash();
      if (sPreviousHash !== undefined) {
        window.history.go(-1);
      } else {
        const oOwnerComponent = oController.getOwnerComponent();
        oOwnerComponent?.getRouter().navTo(sDefaultRoute, {}, true);
      }
    }

    /**
     * Triggers forward routing navigation to a specified target route with parameters
     */
    static navTo(oController, sRouteName, oParameters = {}) {
      const oOwnerComponent = oController.getOwnerComponent();
      oOwnerComponent?.getRouter().navTo(sRouteName, oParameters);
    }
    static navToGenericDetails(oController, oEvent, sDefaultRoute = "ProductDetails") {
      const oControl = oEvent.getSource();
      if (!oControl) return;
      const sTargetRoute = oControl.data("targetRoute") || sDefaultRoute;
      const oCtx = oControl.getBindingContext();
      if (oCtx) {
        const sEntityId = oCtx.getProperty("ID");
        const sPath = oCtx.getPath();
        const sCleanPath = sPath.startsWith("/") ? sPath.substring(1) : sPath;
        const sEntityName = sCleanPath.split("(")[0];
        const oRouteParams = {};
        const sParamName = sEntityName.toLowerCase().replace(/s$/, "") + "Id";
        oRouteParams[sParamName] = sEntityId;
        this.navTo(oController, sTargetRoute, oRouteParams);
      }
    }
    static onImageLoadError(oEvent) {
      const oImageCtrl = oEvent.getSource();
      if (oImageCtrl) {
        oImageCtrl.setSrc("./assets/img/logo.png");
      }
    }
  }
  return NavigationManager;
});
//# sourceMappingURL=NavigationManager-dbg.js.map
