sap.ui.define(["sap/ui/model/json/JSONModel"], function (JSONModel) {
  "use strict";

  /**
   * @namespace sap.capire.gameshop.utils
   */
  class CustomerManager {
    // true — mock realization (ID from localStorage)
    // false — localStorage just in localhost
    static isTestingVersion = true;

    /**
     Get Customer ID to create Client Page
     */
    static async getCurrentCustomerId(oView, oODataModel) {
      if (this.isTestingVersion) {
        console.log("[AUTODEV CUSTOMER LOG]: Testing Mode active. Fetching ID directly from localStorage.");
        return this._getIdFromLocalStorage();
      }
      const sHostname = window.location.hostname;
      if (sHostname === "localhost" || sHostname === "127.0.0.1") {
        console.log("[AUTODEV CUSTOMER LOG]: Production Mode active on localhost. Using localStorage fallback.");
        return this._getIdFromLocalStorage();
      }
      console.log("[AUTODEV CUSTOMER LOG]: Production Mode active in Cloud. Intercepting AppRouter session...");
      const oUserApiModel = new JSONModel();
      const oLoadPromise = oUserApiModel.loadData("/user-api/currentUser", undefined, true, "GET");
      const oBundle = sap.ui.getCore().getModel("i18n")?.getResourceBundle();
      if (!oLoadPromise) {
        throw new Error(oBundle?.getText("customerManager.error.sessionPromise") || "Failed to initialize AppRouter session promise.");
      }
      try {
        await oLoadPromise;
        const oRawData = oUserApiModel.getData();
        if (!oRawData || typeof oRawData !== "object" || !("name" in oRawData)) {
          throw new Error(oBundle?.getText("customerManager.error.invalidSessionData") || "Invalid session data structure received from user-api.");
        }
        const oUserInfo = oRawData;
        const sSessionUsername = oUserInfo.name;
        if (!sSessionUsername) {
          throw new Error(oBundle?.getText("customerManager.error.emptyUsername") || "Session username is empty.");
        }
        if (sSessionUsername === "admin") {
          return "77777777-7777-7777-7777-777777777777";
        }
        return "";
      } catch (oError) {
        console.error("[AUTODEV CUSTOMER LOG]: Cloud session capture failed:", oError);
        throw oError;
      }
    }
    static getBindingPath(sCustomerId) {
      return sCustomerId ? `/ClientProfile(ID=${sCustomerId},IsActiveEntity=true)` : "";
    }

    /**
     * Safe ID Extraction
     */
    static _getIdFromLocalStorage() {
      const sSavedUserJson = window.localStorage.getItem("catConnect_userProfile");
      if (!sSavedUserJson) {
        console.warn("[AUTODEV CUSTOMER LOG]: No profile found in localStorage. User is Guest.");
        return "";
      }
      try {
        const oUserProfile = JSON.parse(sSavedUserJson);
        return oUserProfile?.id || "";
      } catch (e) {
        console.error("[AUTODEV CUSTOMER LOG]: Failed to parse user profile from localStorage.");
        return "";
      }
    }
    static async bindProfileView(oView, fnRedirect) {
      const oODataModel = oView.getModel();
      if (!oView || !oODataModel) {
        return;
      }
      const sCustomerId = await this.getCurrentCustomerId(oView, oODataModel);
      if (!sCustomerId) {
        fnRedirect();
        return;
      }
      const sBindingPath = this.getBindingPath(sCustomerId);
      oView.bindElement({
        path: sBindingPath,
        parameters: {
          "$$patchToMultipleFields": true
        },
        events: {
          dataRequested: () => oView.setBusy(true),
          dataReceived: () => oView.setBusy(false)
        }
      });
    }
  }
  return CustomerManager;
});
//# sourceMappingURL=CustomerManager-dbg.js.map
