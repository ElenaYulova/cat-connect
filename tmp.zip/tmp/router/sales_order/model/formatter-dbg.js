sap.ui.define(["sap/ui/core/Component", "sap/ui/core/library"], function (Component, sap_ui_core_library) {
  "use strict";

  const ValueState = sap_ui_core_library["ValueState"];
  /**
   * @namespace sap.capire.gameshop.model
   */
  class Formatter {
    static formatStock(iStock) {
      const oResourceBundle = sap.ui.getCore().getModel("i18n")?.getResourceBundle();
      if (iStock === undefined || iStock === null) return oResourceBundle?.getText("formatter.stock.noData") || "No data";
      return iStock > 0 ? iStock.toString() : oResourceBundle?.getText("formatter.stock.outOfStock") || "Out of stock";
    }
    static formatStockVisible(iStock) {
      return typeof iStock === "number" && iStock > 0;
    }
    static formatOutOfStockVisible(iStock) {
      return iStock === undefined || iStock === null || iStock <= 0;
    }
    static isFieldVisibleInReadMode(bEditMode) {
      const oControl = this;
      if (!oControl || typeof oControl.getModel !== "function") return false;
      const oComponent = Component.getOwnerComponentFor(oControl);
      const oRolesModel = oComponent ? oComponent.getModel("userRoles") : null;
      if (!oRolesModel) return false;
      const bIsCRMAdmin = oRolesModel.getProperty("/isCRMAdmin");
      const bIsSupplier = oRolesModel.getProperty("/isSupplier");
      return (bIsCRMAdmin || bIsSupplier) && !bEditMode;
    }
    static isFieldVisibleInEditMode(bEditMode) {
      const oControl = this;
      if (!oControl || typeof oControl.getModel !== "function") return false;
      const oComponent = Component.getOwnerComponentFor(oControl);
      const oRolesModel = oComponent ? oComponent.getModel("userRoles") : null;
      if (!oRolesModel) return false;
      const bIsCRMAdmin = oRolesModel.getProperty("/isCRMAdmin");
      const bIsSupplier = oRolesModel.getProperty("/isSupplier");
      return (bIsCRMAdmin || bIsSupplier) && bEditMode;
    }
    static onPriceLiveChange(oEvent) {
      const oInput = oEvent.getSource();
      if (!oInput) return;
      let sValue = oInput.getValue();
      let sCleaned = sValue.replace(/,/g, ".").replace(/\s/g, "").replace(/[^\d.]/g, "");
      if (sValue !== sCleaned) oInput.setValue(sCleaned);
    }
    static onStockLiveChange(oEvent) {
      const oInput = oEvent.getSource();
      if (!oInput) return;
      let sValue = oInput.getValue();
      let sCleaned = sValue.replace(/\s/g, "").replace(/[^\d]/g, "");
      if (sValue !== sCleaned) oInput.setValue(sCleaned);
    }
    static formatAddToCartEnabled(bIsLoggedIn, iCurrentQuantity, iStock) {
      if (!bIsLoggedIn) return false;
      const iQty = Number(iCurrentQuantity) || 0;
      const iAvailable = Number(iStock) || 0;
      return iQty > 0 && iQty <= iAvailable;
    }

    /**
     * Localized state text mapper
     */
    static orderStatusText(sStatusCode) {
      const oResourceBundle = sap.ui.getCore().getModel("i18n")?.getResourceBundle();
      switch (sStatusCode) {
        case "new":
        case "N":
          return oResourceBundle?.getText("formatter.orderStatus.new") || "New Request";
        case "in_process":
        case "P":
          return oResourceBundle?.getText("formatter.orderStatus.inProgress") || "In Progress";
        case "completed":
        case "C":
          return oResourceBundle?.getText("formatter.orderStatus.completed") || "Completed";
        case "cancelled":
        case "X":
          return oResourceBundle?.getText("formatter.orderStatus.cancelled") || "Cancelled";
        default:
          return sStatusCode || oResourceBundle?.getText("formatter.orderStatus.pending") || "Pending";
      }
    }
    static orderStatusState(sStatusCode) {
      switch (sStatusCode) {
        case "new":
        case "N":
          return ValueState.Information;
        case "in_process":
        case "P":
          return ValueState.Warning;
        case "completed":
        case "C":
          return ValueState.Success;
        case "cancelled":
        case "X":
          return ValueState.Error;
        default:
          return ValueState.None;
      }
    }

    /**
     * Formatter to safely merge customer first and last names
     */
    static formatCustomerFullName(sFirstName, sLastName) {
      const sFirst = sFirstName || "";
      const sLast = sLastName || "";
      const sFullName = `${sFirst} ${sLast}`.trim();
      if (!sFullName) {
        const oResourceBundle = sap.ui.getCore().getModel("i18n")?.getResourceBundle();
        return oResourceBundle?.getText("formatter.customer.anonymous") || "Anonymous Customer";
      }
      return sFullName;
    }
  }
  return Formatter;
});
//# sourceMappingURL=formatter-dbg.js.map
