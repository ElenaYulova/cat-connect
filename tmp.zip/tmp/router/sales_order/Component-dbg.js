sap.ui.define(["sap/ui/core/UIComponent", "sap/ui/model/json/JSONModel"], function (UIComponent, JSONModel) {
  "use strict";

  /**
   * @namespace sap.capire.gameshop
   */
  const Component = UIComponent.extend("sap.capire.gameshop.Component", {
    metadata: {
      manifest: "json"
    },
    init: function _init() {
      UIComponent.prototype.init.call(this);
      this.getRouter().initialize();

      // Cross-cutting Cart

      const oCartModel = new JSONModel({
        items: [],
        totalItems: 0,
        totalPrice: 0.00
      });
      this.setModel(oCartModel, "cart");

      // Global Role model

      const sSavedUserJson = window.localStorage.getItem("catConnect_userProfile");
      let oUserData;
      if (sSavedUserJson) {
        try {
          oUserData = JSON.parse(sSavedUserJson);
        } catch (e) {
          oUserData = null;
        }
      }
      const oResourceModel = this.getModel("i18n");
      const oResourceBundle = oResourceModel.getResourceBundle();
      const oRoleModel = new JSONModel({
        isLoggedIn: !!oUserData,
        username: oUserData ? oUserData.username : "Guest",
        welcomeText: oUserData ? oResourceBundle.getText("app.welcome.user", [oUserData.username]) : oResourceBundle.getText("app.welcome.guest"),
        isCRMAdmin: oUserData ? !!oUserData.isCRMAdmin : false,
        isSupplier: oUserData ? !!oUserData.isSupplier : false
      });
      this.setModel(oRoleModel, "userRoles");
    }
  });
  return Component;
});
//# sourceMappingURL=Component-dbg.js.map
